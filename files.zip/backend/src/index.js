const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

const jobsRouter = require("./routes/jobs");
const interviewsRouter = require("./routes/interviews");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/jobs", jobsRouter);
app.use("/api/interviews", interviewsRouter);

// simple health
app.get("/api/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`HireIQ backend listening on ${PORT}`);
});