const express = require("express");
const router = express.Router();

// Simple in-memory job store for demo
const JOBS = {};

// Create job
router.post("/", (req, res) => {
  const { title, description, skills = [], customQuestions = [], creatorId } = req.body;
  const id = `job_${Date.now()}`;
  const job = { id, title, description, skills, customQuestions, creatorId, createdAt: Date.now() };
  JOBS[id] = job;
  res.status(201).json({ job });
});

// List jobs (optionally by creatorId)
router.get("/", (req, res) => {
  const { creatorId } = req.query;
  const list = Object.values(JOBS).filter(j => (creatorId ? j.creatorId === creatorId : true));
  res.json({ jobs: list });
});

// Get job
router.get("/:jobId", (req, res) => {
  const job = JOBS[req.params.jobId];
  if (!job) return res.status(404).json({ error: "not found" });
  res.json({ job });
});

module.exports = router;