const express = require("express");
const router = express.Router();
const { generateChat } = require("../services/openai");
const { computeScores } = require("../utils/scoring");

// In-memory store for quick demo. Replace with Firebase in prod.
const INTERVIEWS = {};

// start interview -> generate questions
router.post("/start", async (req, res) => {
  const { jobId, mode, applicantId, job } = req.body;
  try {
    const prompt = [
      { role: "system", content: "You are an expert interviewer. Produce 6 interview questions as a JSON array with fields: question, type (behavioral|technical|fit), difficulty (1-3)." },
      { role: "user", content: `Job: ${job?.title || "Practice"}\nSkills: ${Array.isArray(job?.skills) ? job.skills.join(", ") : job?.skills || "general"}\nDescription: ${job?.description || ""}\nCustom questions: ${JSON.stringify(job?.customQuestions || [])}` }
    ];
    const qText = await generateChat(prompt);
    let questions = [];
    try {
      const parsed = JSON.parse(qText);
      if (Array.isArray(parsed)) questions = parsed.slice(0, 6);
      else questions = [];
    } catch (e) {
      // fallback: split lines
      questions = (qText || "").split("\n").filter(Boolean).slice(0, 6).map((q, i) => ({ question: q.replace(/^\d+\.\s*/, ""), type: "general", difficulty: 2 }));
    }
    if (!questions.length) {
      // canned fallback
      questions = [
        { question: "Tell me about yourself and your recent work.", type: "behavioral", difficulty: 1 },
        { question: "What's a challenging bug you fixed recently and how did you debug it?", type: "technical", difficulty: 2 },
        { question: "Describe how you approach designing a new feature.", type: "technical", difficulty: 2 },
        { question: "How do you prioritize tasks and communicate status?", type: "fit", difficulty: 1 },
        { question: "Explain a trade-off you made in a past project.", type: "technical", difficulty: 3 },
        { question: "Why are you interested in this role?", type: "fit", difficulty: 1 }
      ];
    }

    const interviewId = `int_${Date.now()}`;
    INTERVIEWS[interviewId] = { id: interviewId, job, applicantId, mode, questions, answers: [], createdAt: Date.now() };
    res.json({ interviewId, questions });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "failed to generate questions", details: err.message });
  }
});

// submit per-question answer
router.post("/:interviewId/submitAnswer", async (req, res) => {
  const { interviewId } = req.params;
  const { answerText, questionIndex, faceMetrics = {}, audioMetrics = {} } = req.body;
  const interview = INTERVIEWS[interviewId];
  if (!interview) return res.status(404).json({ error: "interview not found" });

  const q = interview.questions[questionIndex];
  const prompt = [
    { role: "system", content: "You are an objective evaluator. Return a JSON object with fields: communication (0-10), technical (0-10), confidence (0-10), followUp (optional string), notes (short)." },
    { role: "user", content: `Question: ${q.question}\nTranscript: ${answerText}\nFaceMetrics: ${JSON.stringify(faceMetrics)}\nAudioMetrics: ${JSON.stringify(audioMetrics)}` }
  ];
  try {
    const evalText = await generateChat(prompt, 200);
    let evalObj;
    try { evalObj = JSON.parse(evalText); } catch (e) { evalObj = { raw: evalText }; }
    interview.answers.push({ questionIndex, answerText, faceMetrics, audioMetrics, eval: evalObj });
    res.json({ status: "ok", eval: evalObj });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "evaluation failed", details: err.message });
  }
});

// complete interview -> aggregate and create final report
router.post("/:interviewId/complete", async (req, res) => {
  const { interviewId } = req.params;
  const interview = INTERVIEWS[interviewId];
  if (!interview) return res.status(404).json({ error: "not found" });

  const perQuestionEvals = interview.answers.map(a => a.eval || {});
  const scores = computeScores(perQuestionEvals);

  const prompt = [
    { role: "system", content: "You are HireIQ. Produce a one-paragraph feedback summary and three short bullet strengths and three short bullet areas to improve given aggregated scores and per-question notes. Return plain text." },
    { role: "user", content: `Applicant aggregate scores: ${JSON.stringify(scores)}. Per-question notes: ${JSON.stringify(interview.answers.map(a => a.eval?.notes || ""))}` }
  ];
  try {
    const feedback = await generateChat(prompt, 300);
    const report = {
      id: `rep_${Date.now()}`,
      interviewId,
      job: interview.job,
      applicantId: interview.applicantId,
      scores,
      feedback,
      raw: interview,
      createdAt: Date.now()
    };
    // store in memory for demo:
    interview.report = report;
    res.json({ report });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "report generation failed", details: err.message });
  }
});

// get report
router.get("/:interviewId/report", (req, res) => {
  const interview = INTERVIEWS[req.params.interviewId];
  if (!interview || !interview.report) return res.status(404).json({ error: "not found" });
  res.json({ report: interview.report });
});

module.exports = router;