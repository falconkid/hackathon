const OpenAI = require("openai");
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY || "" });

async function generateChat(messages, maxTokens = 400) {
  // Use Chat Completions endpoint
  const resp = await client.chat.completions.create({
    model: "gpt-4o-mini", // change to available model in your account if necessary
    messages,
    max_tokens: maxTokens,
    temperature: 0.7,
  });
  return resp.choices[0].message.content;
}

module.exports = { generateChat };