// Minimal firebase-admin stub. If you will use Firebase persistence, initialize admin here.
const admin = require("firebase-admin");

function initFirebase(serviceAccountPath) {
  if (admin.apps.length) return admin;
  if (serviceAccountPath) {
    const serviceAccount = require(serviceAccountPath);
    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });
  } else {
    // No-op for demo (in-memory)
    console.warn("Firebase Admin not initialized because no service account provided.");
  }
  return admin;
}

module.exports = { initFirebase, admin };