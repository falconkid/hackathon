// Small helper to combine signals into final scores
function computeScores(perQuestionEvals = []) {
  if (!perQuestionEvals.length) {
    return { problemSolving: 50, communication: 50, confidence: 50, overall: 50 };
  }
  let sumComm = 0, sumTech = 0, sumConf = 0, n = 0;
  perQuestionEvals.forEach(e => {
    const c = Number(e.communication) || 5;
    const t = Number(e.technical) || 5;
    const f = Number(e.confidence) || 5;
    sumComm += c;
    sumTech += t;
    sumConf += f;
    n++;
  });
  const meanComm = sumComm / n;
  const meanTech = sumTech / n;
  const meanConf = sumConf / n;

  const problemSolving = Math.round(meanTech * 10);
  const communication = Math.round(meanComm * 10);
  const confidence = Math.round(meanConf * 10);
  const overall = Math.round(0.45 * problemSolving + 0.35 * communication + 0.2 * confidence);

  return { problemSolving, communication, confidence, overall };
}

module.exports = { computeScores };