import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import RecruiterDashboard from "./pages/RecruiterDashboard";
import ApplicantHome from "./pages/ApplicantHome";
import InterviewPage from "./pages/InterviewPage";
import ReportPage from "./pages/ReportPage";

function Nav() {
  return (
    <nav className="bg-white shadow p-4">
      <div className="container mx-auto flex gap-4">
        <Link to="/" className="font-bold text-indigo-600">HireIQ</Link>
        <Link to="/recruiter/dashboard" className="text-gray-600">Recruiter Dashboard</Link>
        <Link to="/" className="text-gray-600">Applicant</Link>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Nav />
      <div className="container mx-auto p-6">
        <Routes>
          <Route path="/" element={<ApplicantHome />} />
          <Route path="/recruiter/dashboard" element={<RecruiterDashboard />} />
          <Route path="/interview/:id" element={<InterviewPage />} />
          <Route path="/report/:id" element={<ReportPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}