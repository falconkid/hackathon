import React, { useState } from "react";

// Simple wrapper using Web Speech API if supported; otherwise a textarea is used.
export default function SpeechTranscriber({ onTranscript }) {
  const [text, setText] = useState("");
  const [listening, setListening] = useState(false);
  let recognitionRef = null;

  const startListening = () => {
    const Rec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Rec) {
      alert("SpeechRecognition not supported — please type your answer.");
      return;
    }
    const r = new Rec();
    r.lang = "en-US";
    r.interimResults = true;
    r.onresult = (e) => {
      const t = Array.from(e.results).map(r => r[0].transcript).join("");
      setText(t);
      onTranscript && onTranscript(t);
    };
    r.onend = () => setListening(false);
    r.start();
    recognitionRef = r;
    setListening(true);
  };

  return (
    <div>
      <textarea value={text} onChange={(e) => { setText(e.target.value); onTranscript && onTranscript(e.target.value); }} className="w-full p-2 border rounded h-24" />
      <div className="mt-2 flex gap-2">
        <button className="px-3 py-1 bg-gray-200 rounded" onClick={startListening}>Start Listening</button>
        <div className="text-sm text-gray-500 self-center">{listening ? "Listening..." : ""}</div>
      </div>
    </div>
  );
}