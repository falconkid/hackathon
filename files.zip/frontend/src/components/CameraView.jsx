import React, { useEffect, useRef } from "react";

// Minimal camera component emitting fake face metrics for demo.
// Replace with face-api.js detection loop for real metrics.
export default function CameraView({ onFaceMetrics }) {
  const videoRef = useRef();

  useEffect(() => {
    let stream;
    let timer;
    async function start() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        // emit fake metrics every second for demo
        timer = setInterval(() => {
          const metrics = {
            confidence: Number((Math.random() * 0.4 + 0.6).toFixed(2)),
            engagement: Number(Math.random().toFixed(2)),
            expressions: { happy: Math.random(), neutral: Math.random(), surprised: Math.random() }
          };
          onFaceMetrics && onFaceMetrics(metrics);
        }, 1000);
      } catch (e) {
        console.warn("Camera start failed", e);
      }
    }
    start();
    return () => {
      if (timer) clearInterval(timer);
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  return <video ref={videoRef} className="w-full rounded bg-black" playsInline muted />;
}