import React from "react";

export default function ReportPage() {
  const raw = sessionStorage.getItem("hireiq_latest_report");
  const report = raw ? JSON.parse(raw) : null;
  if (!report) return <div className="p-6 bg-white rounded shadow">No report found in session. Complete an interview first.</div>;

  return (
    <div className="bg-white p-6 rounded shadow">
      <h2 className="text-2xl font-semibold mb-2">HireIQ Report</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 border rounded">
          <div className="text-sm text-gray-500">Problem Solving</div>
          <div className="text-2xl font-bold">{report.scores.problemSolving}</div>
        </div>
        <div className="p-4 border rounded">
          <div className="text-sm text-gray-500">Communication</div>
          <div className="text-2xl font-bold">{report.scores.communication}</div>
        </div>
        <div className="p-4 border rounded">
          <div className="text-sm text-gray-500">Confidence</div>
          <div className="text-2xl font-bold">{report.scores.confidence}</div>
        </div>
      </div>
      <div className="mt-4">
        <h3 className="font-semibold">Summary</h3>
        <p className="mt-2 text-gray-700 whitespace-pre-wrap">{report.feedback}</p>
      </div>
    </div>
  );
}