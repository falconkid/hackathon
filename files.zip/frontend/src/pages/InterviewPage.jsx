import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import CameraView from "../components/CameraView";
import SpeechTranscriber from "../components/SpeechTranscriber";

export default function InterviewPage() {
  const [interview, setInterview] = useState(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [transcript, setTranscript] = useState("");
  const [status, setStatus] = useState("idle");
  const [faceMetrics, setFaceMetrics] = useState({});
  const interviewIdRef = useRef(null);

  useEffect(() => {
    (async () => {
      // If URL contains a param id pointing to generated interviewId, use it.
      // For demo we call start to get an interview
      try {
        const r = await axios.post(`${import.meta.env.VITE_API_BASE}/api/interviews/start`, {
          mode: "practice",
          job: { title: "Practice: Frontend", skills: ["React", "UX"], description: "Mock demo." }
        });
        setInterview(r.data);
        interviewIdRef.current = r.data.interviewId;
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  async function submitAnswer() {
    setStatus("submitting");
    try {
      await axios.post(`${import.meta.env.VITE_API_BASE}/api/interviews/${interviewIdRef.current}/submitAnswer`, {
        answerText: transcript,
        questionIndex: currentQ,
        faceMetrics,
        audioMetrics: { duration: Math.max(1, Math.round(transcript.split(" ").length / 2)) }
      });
      setStatus("submitted");
      if (currentQ + 1 < interview.questions.length) {
        setCurrentQ(currentQ + 1);
        setTranscript("");
        setStatus("idle");
      } else {
        const r = await axios.post(`${import.meta.env.VITE_API_BASE}/api/interviews/${interviewIdRef.current}/complete`);
        const report = r.data.report;
        // Simple client-side redirect to report page using report id
        // For demo we temporarily store report in sessionStorage
        sessionStorage.setItem("hireiq_latest_report", JSON.stringify(report));
        window.location.href = `/report/${report.id}`;
      }
    } catch (e) {
      console.error(e);
      setStatus("error");
    }
  }

  if (!interview) return <div className="p-6">Starting interview...</div>;
  const q = interview.questions[currentQ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <CameraView onFaceMetrics={(m) => { setFaceMetrics(m); }} />
      </div>
      <div>
        <div className="bg-white p-4 rounded shadow">
          <h3 className="text-lg font-semibold">AI Interviewer</h3>
          <p className="mt-2 text-gray-700">{q.question}</p>
          <div className="mt-4">
            <SpeechTranscriber onTranscript={(t) => setTranscript(t)} />
            <div className="mt-2 flex gap-2">
              <button className="px-4 py-2 bg-indigo-600 text-white rounded" onClick={submitAnswer}>Submit Answer</button>
              <div className="text-sm text-gray-500 self-center">Status: {status}</div>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <div className="bg-white p-4 rounded shadow">
            <h4 className="font-semibold">Progress</h4>
            <div className="mt-2">
              Question {currentQ + 1} of {interview.questions.length}
            </div>
            <div className="mt-2 text-xs text-gray-500">Face metrics: {JSON.stringify(faceMetrics)}</div>
          </div>
        </div>
      </div>
    </div>
  );
}