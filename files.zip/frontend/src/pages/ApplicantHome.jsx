import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ApplicantHome() {
  const [jobs, setJobs] = useState([]);
  useEffect(() => {
    (async () => {
      try {
        const r = await axios.get(`${import.meta.env.VITE_API_BASE}/api/jobs`);
        setJobs(r.data.jobs || []);
      } catch (e) {
        setJobs([]);
      }
    })();
  }, []);

  async function startPractice() {
    const r = await axios.post(`${import.meta.env.VITE_API_BASE}/api/interviews/start`, {
      mode: "practice",
      job: { title: "Practice Interview", skills: ["Communication", "Problem Solving"], description: "Practice mode" }
    });
    window.location.href = `/interview/${r.data.interviewId}`;
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Applicant</h1>
      <div className="mb-4">
        <button onClick={startPractice} className="px-4 py-2 bg-indigo-600 text-white rounded">Start Practice Interview</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {jobs.map(job => (
          <div key={job.id} className="bg-white p-4 rounded shadow">
            <h2 className="font-bold">{job.title}</h2>
            <p className="text-sm text-gray-600">{job.description}</p>
            <div className="mt-2">
              <a className="text-indigo-600" href={`/interview/${job.id}`}>Start Interview (demo)</a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}