import React, { useEffect, useState } from "react";
import axios from "axios";

export default function RecruiterDashboard() {
  const [jobs, setJobs] = useState([]);
  useEffect(() => {
    // For demo, fetch jobs from backend
    (async () => {
      try {
        const r = await axios.get(`${import.meta.env.VITE_API_BASE}/api/jobs`);
        setJobs(r.data.jobs || []);
      } catch (e) {
        console.warn("Failed to fetch jobs", e);
        setJobs([]);
      }
    })();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Recruiter Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {jobs.length ? jobs.map(job => (
          <div key={job.id} className="bg-white p-4 rounded shadow">
            <h2 className="font-bold">{job.title}</h2>
            <p className="text-sm text-gray-600">{job.description}</p>
            <div className="mt-2 text-xs text-gray-500">Skills: {job.skills?.join(", ")}</div>
          </div>
        )) : <div className="p-4 bg-white rounded shadow">No jobs yet (create one via API)</div>}
      </div>
    </div>
  );
}